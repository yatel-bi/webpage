SPANISH
=======

- README.txt: este archivo
- LICENSE.txt: licencia de todos los archivos
- tutorial_es.pdf: un instructivo de como usar los colores y los logos
- yatel_color.svg: logo en color formato vectorial
- yatel_bw.svg: logo en bw formato vectorial
- favicon_color.ico: Utilizable como favicon html a color.
- favicon_bw.ico: Utilizable como favicon html blanco y negro.
- yatel_color_<big|medium|small>.png: logos a color en diferentes tamaños.
- yatel_bw_<big|medium|small>.png: logos blanco y negro en diferentes tamaños.

DESIGNER: Paula Lorca <paulalorca89@hotmail.com>
